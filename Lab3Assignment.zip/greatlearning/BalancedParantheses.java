package com.datastructures.learn.com.greatlearning;

import java.util.Stack;

public class BalancedParantheses {

    public static void main(String[] args) {
        Stack<Character> stack = new Stack<>();
        String inputString = "([[{}]])";
        char[] strArray = inputString.toCharArray();
        System.out.println("The hard-coded input String : "+inputString);
        int i = 0;

        while (i < strArray.length) {
            Character element = strArray[i];
            if (strArray[i] == '{' || strArray[i] == '[' || strArray[i] == '(') {
                stack.push(strArray[i]);
            }
            else {
                if(stack.isEmpty()){
                    break;
                }
                else {
                    Character popString = stack.peek();
                    if ((popString == '{' && strArray[i] == '}') || (popString == '[' && strArray[i] == ']') || (popString == '(' && strArray[i] == ')')) {
                        stack.pop();
                    }
                }

            }
            i++;
        }
        if (stack.isEmpty() && i >=strArray.length) {
            System.out.println("Balanced Brackets!");
        } else {
            System.out.println("Unbalanced Brackets");
        }
    }
}
