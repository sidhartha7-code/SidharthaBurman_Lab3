package com.datastructures.learn.com.greatlearning;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class FindSumPair {
    ArrayList<Integer> list=new ArrayList<Integer>();
    int count=0;
    static class Node {
        int nodeData;
        Node leftNode, rightNode;
        public Node(int data){
            this.nodeData=data;
        }
    }
    static  Node newNode(int key){
        Node temp=new Node(key);
        //temp.nodeData=data;
        temp.leftNode=null;
        temp.rightNode=null;

        return temp;
    }

    private Node insert(Node root, int i) {
        if (root==null) {
            root=new Node(i);
            return root;
        }
        if (i < root.nodeData) {
            root.leftNode = insert(root.leftNode, i);
        }
        else{
            root.rightNode=insert(root.rightNode,i);
            }
        return root;
        }

    public void InOrder(Node root){
        if (root==null){
            return;
        }
        InOrder(root.leftNode);
        System.out.print(root.nodeData+" ");
        list.add(root.nodeData);
        InOrder(root.rightNode);
        count++;
    }

    private void FindPairSum(Node root, int sum) {
        InOrder(root);
        int start = 0;
        int end = list.size()-1;
        System.out.println(" ");

        ArrayList<Integer> result = new ArrayList<>();
        while (start < end) {
            //System.out.println("Start: " + start + " End :" + end);
            if (list.get(start) + list.get(end) == sum) {
                result.add(list.get(start));
                result.add(list.get(end));
                Iterator<Integer> out=result.iterator();
                System.out.print("Pair Found!. The elements are : ");
                while(out.hasNext()){
                    System.out.print(out.next()+" ");
                }
                break;
            }
            if (list.get(start) + list.get(end) < sum) {
                start++;
            } else {
                end--;
            }
            if(start==end){
                System.out.println("Pair not Found!");
            }

        }

    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Node root=null;
        FindSumPair pair=new FindSumPair();
        root=pair.insert(null,40);
        pair.insert(root,20);
        pair.insert(root,60);
        pair.insert(root,10);
        pair.insert(root,30);
        pair.insert(root,50);
        pair.insert(root,70);

        System.out.print("The elements of the tree are :");
        pair.InOrder(root);
        System.out.println("");
        System.out.println("Please Enter the Target Sum: ");
        int sum=sc.nextInt();
        System.out.print("Inorder Traversal :");
        pair.FindPairSum(root,sum);
    }
}

